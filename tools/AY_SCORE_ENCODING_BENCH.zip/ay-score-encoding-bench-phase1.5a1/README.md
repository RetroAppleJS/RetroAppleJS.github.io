# AY Score Encoding Bench v0.1.1 — Phase 1.5A.1

Standalone experimental music score encoding, decoding, memory and two-mode full-speed scheduling bench for the RetroAppleJS SID-to-AY translator research.

## Run in a browser

**Simplest:** open `tools/AY_SCORE_ENCODING_BENCH_standalone.html` (single HTML file; no external scripts or network required).

**Modular:** open `tools/AY_SCORE_ENCODING_BENCH.html` (requires companion `tools/AY_SCORE_ENCODING_BENCH_core.js` in the same folder).

The five encoders are E0 raw absolute, E1 delta varint, E2 bounded event-pattern LZ, E3 procedural instrument VM, and E4 hybrid VM+direct / event fallback. Six synthetic scenarios and v1.4 Waveform Bench JSON event imports are supported. The UI exports binary `.aysb`, aggregate JSON, CSV and canonical event JSON.

## Test in browser (recommended)

Open the standalone HTML and click **Run browser scheduler checks (7)**. Select **Interrupt priority** and **Cooperative** from the scheduling mode control, rerun the cost model, inspect latency breakdown and export the JSON results. No Node or terminal is required.

## Optional developer tests

```bash
node --test tests/ay_score_encoding_bench.test.js
```

No dependencies are needed for the Node tests. See `docs/AY_SCORE_ENCODING_BENCH.md` for full API, binary layout, limits, instrument semantics, memory accounting, timing model and known limitations.

**Evidence levels:** Byte counts and event-sequence round trips are computed facts for the generated binary. Estimates of 6502 decode/player size, required RAM, scheduler overhead and graphics coexistence are *models*, not instrumented hardware measurements. This tool does not convert or play PSID files, generate sound, or modify RetroAppleJS emulator/peripheral code.

Phase 1.5A.1 changes only the CPU/graphics scheduler and telemetry, not the E0–E4 binary formats. See the expanded scheduler reference in `docs/AY_SCORE_ENCODING_BENCH.md`.

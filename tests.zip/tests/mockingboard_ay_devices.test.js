'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const {load, root} = require('./helpers/ay_core');

function environment(wasmAvailable = true)
{
    const ctx = load();
    if (!wasmAvailable)
        ctx.WebAssembly = undefined;
    ctx._o = {CPU_ClocksTicks_s : 1000000, CPU_TargetTicks_s : 1000000};
    ctx.oEMU = {component : {IO : {ACTION_MAP : {RD : [], WR : []}}}, system : {}};
    ctx.oEMUI = {};
    ctx._CFG_IOADDR = {};
    ctx._CFG_IORANGES = {};
    ctx.TextEncoder = TextEncoder;
    let hash = 0;
    ctx.oCOM = {crc16 : () => ++hash, getHexWord : n => n.toString(16), addRefreshEvent() {}};
    vm.runInContext(fs.readFileSync(root + '/res/EMU_apple2io.js', 'utf8'), ctx);
    const io = new ctx.Apple2IO({});
    ctx.apple2plus = {hwObj : () => ({io, setIRQSource() {}})};
    vm.runInContext(fs.readFileSync(root + '/res/EMU_DEVICE_mockingboard_audio.js', 'utf8'), ctx);
    vm.runInContext(fs.readFileSync(root + '/res/EMU_CARD_mockingboard.js', 'utf8'), ctx);
    const card = new ctx.mockingboard();
    card.mount = {hash : 27};
    card.restart();
    const elements = {};
    ctx.document = {getElementById : id => elements[id] || null};
    const html = card.deviceToolSlotHTML({toolboxID : 'mock-tools', slotID : 'slot4'});
    for (const name of ['backend', 'backend_status'])
        elements['MOCK_history_27_' + name] = {
            value : 'wasm',
            disabled : false,
            textContent : '',
            title : '',
            style : {},
            setAttribute() {}
        };
    return {ctx, io, card, html, elements};
}

function write(card, reg, value, index = 0)
{
    const base = index * 128, ctx = {cpuTick : 0};
    card.writeSlotROM(base + 2, 7, ctx);
    card.writeSlotROM(base + 3, 255, ctx);
    card.writeSlotROM(base, 4, ctx);
    card.writeSlotROM(base + 1, reg, ctx);
    card.writeSlotROM(base, 7, ctx);
    card.writeSlotROM(base, 4, ctx);
    card.writeSlotROM(base + 1, value, ctx);
    card.writeSlotROM(base, 6, ctx);
    card.writeSlotROM(base, 4, ctx);
}

class AudioContextStub
{
    constructor()
    {
        this.state = 'running';
        this.currentTime = 0;
        this.sampleRate = 44100;
        this.destination = {};
        this.sources = [];
    }
    createGain()
    {
        return {gain : {value : 1}, connect() {}};
    }
    createBuffer(channels, frames, sampleRate)
    {
        const data = Array.from({length : channels}, () => new Float32Array(frames));
        return {duration : frames / sampleRate, getChannelData : i => data[i]};
    }
    createBufferSource()
    {
        const source = {
            playbackRate : {value : 1},
            connect() {},
            start() {},
            stop() {
                this.stopped = true;
            },
            disconnect() {
                this.disconnected = true;
            }
        };
        this.sources.push(source);
        return source;
    }
}

test('actual sink detachment stops scheduled audio and disables its hooks', async () => {
    const {ctx, io, card} = environment();
    ctx.AudioContext = AudioContextStub;
    io.provisionPeripheral(card, 'A2P');
    const sink = card.devices.find(d => d.id.DCODE === 'MOCKAUDIO');
    await sink.init('audio_on');
    write(card, 0, 100);
    write(card, 7, 56);
    write(card, 8, 15);
    card.advanceTo(40000);
    sink.cycle();
    assert.ok(sink.audio.sources.length > 0);
    assert.equal(io.detach(card, 'MOCKAUDIO', sink.attach.hash), true);
    assert.equal(sink.isCycleActive(), false);
    assert.equal(sink.isTickActive(), false);
    assert.ok(sink.audio.sources.every(s => s.stopped && s.disconnected));
    card.onUnmount();
    io.detach(card);
});

test('card ejection cancels pending audio activation through actual IO detachment', async () => {
    const {ctx, io, card} = environment();
    ctx.AudioContext = AudioContextStub;
    io.provisionPeripheral(card, 'A2P');
    const sink = card.devices.find(d => d.id.DCODE === 'MOCKAUDIO');
    await sink.init('audio_ctx');
    let release;
    sink.audio.state = 'suspended';
    sink.audio.resume = () => new Promise(resolve => { release = resolve; });
    const pending = sink.init('audio_on');
    assert.equal(io.detach(card), true);
    card.onUnmount();
    release();
    await pending;
    assert.equal(card.state.active, false);
    assert.equal(sink.isCycleActive(), false);
    assert.equal(card.devices.length, 0);
});

test('each Mockingboard provisions two separate AY devices and defaults to WASM', () => {
    const {ctx, io, card} = environment();
    assert.equal(typeof ctx.AYChipDevice, 'function', 'AY is a device class');
    io.provisionPeripheral(card, 'A2P');
    io.provisionPeripheral(card, 'A2P');
    const chips = card.devices.filter(d => d.id.DCODE === 'AY8910');
    assert.equal(chips.length, 2);
    assert.notEqual(chips[0], chips[1]);
    assert.ok(chips.every(d => d instanceof ctx.AYChipDevice));
    assert.deepEqual(Array.from(chips, d => d.id.deviceN), [ 1, 2 ]);
    assert.notEqual(chips[0].attach.hash, chips[1].attach.hash);
    assert.equal(card.getAYDiagnostics().backend, 'wasm');
    write(card, 0, 100, 0);
    write(card, 0, 200, 1);
    assert.equal(chips[0].getRegisters()[0], 100);
    assert.equal(chips[1].getRegisters()[0], 200);
    assert.ok(io.detach(card, 'AY8910', chips[0].attach.hash));
    assert.equal(chips[0].getState().enabled, false);
    assert.equal(chips[1].getState().enabled, true);
    io.provisionPeripheral(card, 'A2P');
    assert.equal(card.devices.filter(d => d.id.DCODE === 'AY8910').length, 2);
    assert.equal(card.getAYDevice(0), chips[0]);
    assert.equal(chips[0].getRegisters()[0], 100);
    card.onUnmount();
    io.detach(card);
    assert.equal(card.devices.length, 0);
    assert.equal(card.getAudioBufferedSeconds(), 0);
});

test('WASM/JS toolbox selection preserves registers on both AY devices', async () => {
    const {card, html, elements} = environment();
    assert.match(html, /deviceToolAYBackendChange\(this\.value\)/);
    assert.match(html, /<option value="wasm" selected>WASM<\/option>/);
    assert.match(html, /<option value="js">JS<\/option>/);
    for (const index of [0, 1])
    {
        write(card, 0, 100 + index * 100, index);
        write(card, 7, 56, index);
        write(card, 8, 15, index);
    }
    const before = [ Array.from(card.getRegisters(0)), Array.from(card.getRegisters(1)) ];
    assert.equal(await card.deviceToolAYBackendChange('js'), true);
    assert.equal(card.getAYDiagnostics().backend, 'js');
    assert.deepEqual(Array.from(card.getRegisters(0)), before[0]);
    assert.deepEqual(Array.from(card.getRegisters(1)), before[1]);
    assert.equal(elements.MOCK_history_27_backend.value, 'js');
    assert.equal(await card.deviceToolAYBackendChange('wasm'), true);
    assert.deepEqual(Array.from(card.getRegisters(0)), before[0]);
    assert.match(elements.MOCK_history_27_backend_status.textContent, /WASM/);
});

test('failed WASM selection leaves the active JS device pair and reports the error', async () => {
    const {ctx, card, elements} = environment();
    assert.equal(typeof card.deviceToolAYBackendChange, 'function');
    await card.deviceToolAYBackendChange('js');
    write(card, 0, 123);
    ctx.AYCoreWASM.create = async () => { throw ctx.AYCore.error('E_MEMORY', 'WASM unavailable'); };
    assert.equal(await card.deviceToolAYBackendChange('wasm'), false);
    assert.equal(card.getAYDiagnostics().backend, 'js');
    assert.equal(card.getRegisters(0)[0], 123);
    assert.equal(elements.MOCK_history_27_backend.value, 'js');
    assert.equal(elements.MOCK_history_27_backend.disabled, false);
    assert.match(elements.MOCK_history_27_backend_status.textContent, /WASM unavailable/);
});

test('pending backend selection cannot activate after card ejection', async () => {
    const {ctx, card, elements} = environment();
    assert.equal(typeof card.deviceToolAYBackendChange, 'function');
    const create = ctx.AYCore.create.bind(ctx.AYCore);
    let release;
    ctx.AYCore.create = options =>
        new Promise(resolve => { release = () => create(options).then(resolve); });
    const pending = card.deviceToolAYBackendChange('js');
    assert.equal(elements.MOCK_history_27_backend.disabled, true);
    card.onUnmount();
    await release();
    assert.equal(await pending, false);
    assert.equal(card.state.active, false);
    assert.equal(elements.MOCK_history_27_backend.disabled, false);
});

test('unavailable WASM is visibly reported while the JS alternative remains usable', () => {
    const {card, html} = environment(false);
    assert.equal(card.getAYDiagnostics().backend, 'js');
    assert.match(html, /<option value="js" selected>JS<\/option>/);
    assert.match(html, /WebAssembly unavailable/);
    write(card, 0, 100);
    write(card, 7, 56);
    write(card, 8, 15);
    card.setAudioConsumerActive(true);
    card.advanceTo(40000);
    assert.ok(card.drainAudioFrames(4096).left.some(v => v !== 0));
});
